import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# Load VMAF data
with open('ratio_vmaf.json', 'r') as f:
    ratio_data = json.load(f)
with open('gcc_vmaf.json', 'r') as f:
    gcc_data = json.load(f)

# Extract per-frame VMAF scores
ratio_vmaf = [frame['metrics']['vmaf'] for frame in ratio_data['frames']]
gcc_vmaf = [frame['metrics']['vmaf'] for frame in gcc_data['frames']]

# Plot CDF
plt.figure(figsize=(10, 6))

ratio_sorted = np.sort(ratio_vmaf)
gcc_sorted = np.sort(gcc_vmaf)
cdf_ratio = np.arange(1, len(ratio_sorted) + 1) / len(ratio_sorted)
cdf_gcc = np.arange(1, len(gcc_sorted) + 1) / len(gcc_sorted)

plt.plot(ratio_sorted, cdf_ratio, 'b-', linewidth=2, label=f'Ratio (mean={np.mean(ratio_vmaf):.2f})')
plt.plot(gcc_sorted, cdf_gcc, 'r-', linewidth=2, label=f'GCC (mean={np.mean(gcc_vmaf):.2f})')

plt.xlabel('VMAF (higher is better)', fontsize=12)
plt.ylabel('CDF', fontsize=12)
plt.title('VMAF CDF Comparison: Ratio vs GCC', fontsize=14)
plt.legend(fontsize=11)
plt.grid(True, alpha=0.3)
plt.xlim(0, 100)

plt.tight_layout()
plt.savefig('vmaf_cdf_comparison.png', dpi=150)
print(f"CDF图已保存: vmaf_cdf_comparison.png")

print(f"\nRatio VMAF: mean={np.mean(ratio_vmaf):.2f}, P10={np.percentile(ratio_vmaf,10):.2f}, P50={np.percentile(ratio_vmaf,50):.2f}")
print(f"GCC VMAF:   mean={np.mean(gcc_vmaf):.2f}, P10={np.percentile(gcc_vmaf,10):.2f}, P50={np.percentile(gcc_vmaf,50):.2f}")
