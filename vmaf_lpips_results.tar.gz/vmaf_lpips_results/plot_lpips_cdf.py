import os
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import torch
import lpips
from PIL import Image
from tqdm import tqdm

# Setup
loss_fn = lpips.LPIPS(net='alex')
src_dir = "src_frames"
ratio_dir = "ratio_frames"
gcc_dir = "gcc_frames"

# Get frame files
src_files = sorted([f for f in os.listdir(src_dir) if f.endswith('.png')])
ratio_files = sorted([f for f in os.listdir(ratio_dir) if f.endswith('.png')])
gcc_files = sorted([f for f in os.listdir(gcc_dir) if f.endswith('.png')])

n_frames = min(len(src_files), len(ratio_files), len(gcc_files))
print(f"总帧数: {n_frames}, 采样每10帧计算CDF")

sample_indices = list(range(0, n_frames, 10))

def load_image(path):
    img = Image.open(path).convert('RGB')
    img = np.array(img).astype(np.float32) / 255.0
    img = torch.from_numpy(img).permute(2, 0, 1).unsqueeze(0)
    return img * 2 - 1

ratio_lpips = []
gcc_lpips = []

print("计算 LPIPS...")
for i in tqdm(sample_indices):
    src_img = load_image(os.path.join(src_dir, src_files[i]))
    ratio_img = load_image(os.path.join(ratio_dir, ratio_files[i]))
    gcc_img = load_image(os.path.join(gcc_dir, gcc_files[i]))
    
    with torch.no_grad():
        ratio_lpips.append(loss_fn(src_img, ratio_img).item())
        gcc_lpips.append(loss_fn(src_img, gcc_img).item())

# Plot CDF
plt.figure(figsize=(10, 6))

ratio_sorted = np.sort(ratio_lpips)
gcc_sorted = np.sort(gcc_lpips)
cdf = np.arange(1, len(ratio_sorted) + 1) / len(ratio_sorted)

plt.plot(ratio_sorted, cdf, 'b-', linewidth=2, label=f'Ratio (mean={np.mean(ratio_lpips):.4f})')
plt.plot(gcc_sorted, cdf, 'r-', linewidth=2, label=f'GCC (mean={np.mean(gcc_lpips):.4f})')

plt.xlabel('LPIPS (lower is better)', fontsize=12)
plt.ylabel('CDF', fontsize=12)
plt.title('LPIPS CDF Comparison: Ratio vs GCC', fontsize=14)
plt.legend(fontsize=11)
plt.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('lpips_cdf_comparison.png', dpi=150)
print(f"\nCDF图已保存: lpips_cdf_comparison.png")

print(f"\nRatio: mean={np.mean(ratio_lpips):.4f}, P50={np.percentile(ratio_lpips,50):.4f}, P90={np.percentile(ratio_lpips,90):.4f}")
print(f"GCC:   mean={np.mean(gcc_lpips):.4f}, P50={np.percentile(gcc_lpips,50):.4f}, P90={np.percentile(gcc_lpips,90):.4f}")
